LeavesData=struct('No ',{1,2,3,4,5},'CommonName',{'mango','cassava','maize','bean','hibiscus'},'LeafType',{'simple','compound(palmate)','simple','compound(trifoliate)','simple'},'Venation',{'Reticulate','Reticulate','Parallel','Reticulate','Reticulate'},'Margin',{'entire','entire(lobbed)','entire','entire','serrated'},'OriginalImagePath',{'mango leaf.jpeg','cassava leaf.jpeg','maize leaf.jpeg','bean leaf.jpeg','hibiscus leaf.jpeg'},'ProcessedImagePath',{'mango-processed.jpeg','cassava-processed.jpeg','maize-processed.jpeg','bean-processed.jpeg','hibiscuss-processed.jpeg'});
fprintf('Structural array successfully created for %d leaf types.\n',length(LeavesData));
for i=1:length(LeavesData)
    currentImageName=LeavesData(i).OriginalImagePath;
    imgOriginal=imread(currentImageName);
    imgGray=rgb2gray(imgOriginal);
    thresholdValue=graythresh(imgGray);
    imgBinary=imbinarize(imgGray,thresholdValue);
    imgEdges=edge(imgGray,'canny');
    imwrite(imgEdges,LeavesData(i).ProcessedImagePath);
end 